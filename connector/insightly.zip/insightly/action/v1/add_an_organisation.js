module.exports = {

  name: "add_an_organisation",

  title: "Add An Organisation",

  description: "",
  version: "v1",

  input:{
    title: "Add An Organisation",
    type: "object",
    properties: {
      "ORGANISATION_NAME": {
        "title": "Organisation Name",
        "type": "string",
        "description": "Enter Organisation Name",
        "minLength": "1"
      },
      "BACKGROUND": {
        "title": "Description",
        "type": "string",
        "description": "Enter Description"
      },
      "IMAGE_URL": {
        "title": "Image Url",
        "type": "string",
        "description": "Enter Image Url"
      },
      "SOCIAL_LINKEDIN": {
        "title": "LinkedIn",
        "type": "string",
        "description": "Enter valid LinkedIn url"
      },
      "SOCIAL_FACEBOOK": {
        "title": "Facebook",
        "type": "string",
        "description": "Enter valid Facebook url"
      },
      "SOCIAL_TWITTER": {
        "title": "Twitter",
        "type": "string",
        "description": "Enter valid Twitter url"
      },
      "PHONE": {
        "title": "Phone",
        "type": "string",
        "description": "Enter Phone"
      },
      "PHONE_FAX": {
        "title": "Fax",
        "type": "string",
        "description": "Enter Fax"
      },
      "WEBSITE": {
        "title": "Website",
        "type": "string",
        "description": "Enter Website"
      },
      "ADDRESS_BILLING_STREET": {
        "title": "Billing Street",
        "type": "string",
        "description": "Enter Billing Street"
      },
      "ADDRESS_BILLING_CITY": {
        "title": "Billing City",
        "type": "string",
        "description": "Enter Billing City"
      },
      "ADDRESS_BILLING_STATE": {
        "title": "Billing State",
        "type": "string",
        "description": "Enter Billing State"
      },
      "ADDRESS_BILLING_POSTCODE": {
        "title": "Billing Postal Code",
        "type": "string",
        "description": "Enter Billing Postal Code"
      },
      "ADDRESS_BILLING_COUNTRY": {
        "title": "Billing Country",
        "type": "string",
        "description": "Enter Billing Country"
      },
      "ADDRESS_SHIP_STREET": {
        "title": "Ship Street",
        "type": "string",
        "description": "Enter Ship Street"
      },
      "ADDRESS_SHIP_CITY": {
        "title": "Ship City",
        "type": "string",
        "description": "Enter Ship City"
      },
      "ADDRESS_SHIP_STATE": {
        "title": "Ship State",
        "type": "string",
        "description": "Enter Ship State"
      },
      "ADDRESS_SHIP_POSTCODE": {
        "title": "Ship Postal Code",
        "type": "string",
        "description": "Enter Ship Postal Code"
      },
      "ADDRESS_SHIP_COUNTRY": {
        "title": "Ship Country",
        "type": "string",
        "description": "Enter Ship Country"
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "ORGANISATION_ID": {
        "title": "ORGANISATION_ID",
        "type": "integer",
        "displayTitle": "Organisation Id"
      },
      "ORGANISATION_NAME": {
        "title": "ORGANISATION_NAME",
        "type": "string",
        "displayTitle": "Organisation Name"
      },
      "IMAGE_URL": {
        "title": "IMAGE_URL",
        "type": "string",
        "displayTitle": "Image Url"
      },
      "BACKGROUND": {
        "title": "BACKGROUND",
        "type": "string",
        "displayTitle": "Description"
      },
      "OWNER_USER_ID": {
        "title": "OWNER_USER_ID",
        "type": "integer",
        "displayTitle": "Owner User Id"
      },
      "DATE_CREATED_UTC": {
        "title": "DATE_CREATED_UTC",
        "type": "string",
        "displayTitle": "Date Created"
      },
      "DATE_UPDATED_UTC": {
        "title": "DATE_UPDATED_UTC",
        "type": "string",
        "displayTitle": "Date Updated"
      },
      "LAST_ACTIVITY_DATE_UTC": {
        "title": "LAST_ACTIVITY_DATE_UTC",
        "type": "string",
        "displayTitle": "Last Activity Date"
      },
      "NEXT_ACTIVITY_DATE_UTC": {
        "title": "NEXT_ACTIVITY_DATE_UTC",
        "type": "string",
        "displayTitle": "Next Activity Date"
      },
      "SOCIAL_LINKEDIN": {
        "title": "SOCIAL_LINKEDIN",
        "type": "string",
        "displayTitle": "Social Linkedin"
      },
      "SOCIAL_FACEBOOK": {
        "title": "SOCIAL_FACEBOOK",
        "type": "string",
        "displayTitle": "Social Facebook"
      },
      "SOCIAL_TWITTER": {
        "title": "SOCIAL_TWITTER",
        "type": "string",
        "displayTitle": "Social Twitter"
      },
      "PHONE": {
        "title": "PHONE",
        "type": "string",
        "displayTitle": "Phone"
      },
      "PHONE_FAX": {
        "title": "PHONE_FAX",
        "type": "string",
        "displayTitle": "Fax"
      },
      "WEBSITE": {
        "title": "WEBSITE",
        "type": "string",
        "displayTitle": "Website"
      },
      "ADDRESS_BILLING_STREET": {
        "title": "ADDRESS_BILLING_STREET",
        "type": "string",
        "displayTitle": "Billing Street"
      },
      "ADDRESS_BILLING_CITY": {
        "title": "ADDRESS_BILLING_CITY",
        "type": "string",
        "displayTitle": "Billing City"
      },
      "ADDRESS_BILLING_STATE": {
        "title": "ADDRESS_BILLING_STATE",
        "type": "string",
        "displayTitle": "Billing State"
      },
      "ADDRESS_BILLING_POSTCODE": {
        "title": "ADDRESS_BILLING_POSTCODE",
        "type": "string",
        "displayTitle": "Billing Postal Code"
      },
      "ADDRESS_BILLING_COUNTRY": {
        "title": "ADDRESS_BILLING_COUNTRY",
        "type": "string",
        "displayTitle": "Billing Country"
      },
      "ADDRESS_SHIP_STREET": {
        "title": "ADDRESS_SHIP_STREET",
        "type": "string",
        "displayTitle": "Ship Street"
      },
      "ADDRESS_SHIP_CITY": {
        "title": "ADDRESS_SHIP_CITY",
        "type": "string",
        "displayTitle": "Ship City"
      },
      "ADDRESS_SHIP_STATE": {
        "title": "ADDRESS_SHIP_STATE",
        "type": "string",
        "displayTitle": "Ship State"
      },
      "ADDRESS_SHIP_POSTCODE": {
        "title": "ADDRESS_SHIP_POSTCODE",
        "type": "string",
        "displayTitle": "Ship Postal Code"
      },
      "ADDRESS_SHIP_COUNTRY": {
        "title": "ADDRESS_SHIP_COUNTRY",
        "type": "string",
        "displayTitle": "Other Country"
      },
      "CREATED_USER_ID": {
        "title": "CREATED_USER_ID",
        "type": "integer",
        "displayTitle": "Created User Id"
      }
      
    }
  },

  mock_input:{
    "ORGANISATION_NAME": "SAG"
  },

  execute: function(input, output){
    let request = require('request');
    //Create the buffer object by specifying utf8 as encoding type
    let bufferObj = Buffer.from(input.auth.username, "utf8");
    //Encode as base64 string
    let base64String = bufferObj.toString("base64");

    var data = {
      "ORGANISATION_NAME": input.ORGANISATION_NAME,
      "BACKGROUND": input.BACKGROUND,
      "IMAGE_URL": input.IMAGE_URL,
      "SOCIAL_FACEBOOK": input.SOCIAL_FACEBOOK,
      "SOCIAL_TWITTER": input.SOCIAL_TWITTER,
      "SOCIAL_LINKEDIN": input.SOCIAL_LINKEDIN,
      "PHONE": input.PHONE,
      "PHONE_FAX": input.PHONE_FAX,
      "WEBSITE": input.WEBSITE,
      "ADDRESS_BILLING_STREET": input.ADDRESS_BILLING_STREET,
      "ADDRESS_BILLING_CITY": input.ADDRESS_BILLING_CITY,
      "ADDRESS_BILLING_STATE": input.ADDRESS_BILLING_STATE,
      "ADDRESS_BILLING_POSTCODE": input.ADDRESS_BILLING_POSTCODE,
      "ADDRESS_BILLING_COUNTRY": input.ADDRESS_BILLING_COUNTRY,
      "ADDRESS_SHIP_STREET": input.ADDRESS_SHIP_STREET,
      "ADDRESS_SHIP_CITY": input.ADDRESS_SHIP_CITY,
      "ADDRESS_SHIP_STATE": input.ADDRESS_SHIP_STATE,
      "ADDRESS_SHIP_POSTCODE": input.ADDRESS_SHIP_POSTCODE,
      "ADDRESS_SHIP_COUNTRY": input.ADDRESS_SHIP_COUNTRY,

    }
    request({
      url: "https://api.na1.insightly.com/v3.1/Organisations",
      headers: {
        Authorization: "Basic " + base64String
      },
      method: "POST",
      json: data
    },
      function(err, res, body) {
        if (err) {
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string') {
              body = JSON.parse(body);
            }
            return output(null, body);
          } else {
            if (body && body.errors) {
              return output(JSON.stringify(body.errors));
            }
            return output(JSON.stringify(body));
          }
        }
      }
    )
  }

}
