module.exports = {

  name: "update_a_contact",

  title: "Update A Contact",

  description: "",
  version: "v1",

  input:{
    title: "Update A Contact",
    type: "object",
    properties: {
      "SALUTATION": {
        "title": "Salutation",
        "type": "string",
        "description": "Enter Salutation"
      },
      "CONTACT_ID": {
        "title": "Contact Id",
        "type": "integer",
        "description": "Enter contact id",
      },
      "FIRST_NAME": {
        "title": "First Name",
        "type": "string",
        "description": "Enter the first name",
        "minLength": "1"
      },
      "LAST_NAME": {
        "title": "Last Name",
        "type": "string",
        "description": "Enter the last name"
      },
      "SOCIAL_LINKEDIN": {
        "title": "LinkedIn",
        "type": "string",
        "description": "Enter valid LinkedIn url"
      },
      "SOCIAL_FACEBOOK": {
        "title": "Facebook",
        "type": "string",
        "description": "Enter valid Facebook url"
      },
      "SOCIAL_TWITTER": {
        "title": "Twitter",
        "type": "string",
        "description": "Enter valid Twitter url"
      },
      "DATE_OF_BIRTH": {
        "title": "Date Of Birth",
        "type": "string",
        "description": "Enter date of birth"
      },
      "PHONE": {
        "title": "Phone",
        "type": "string",
        "description": "Enter Phone"
      },
      "PHONE_HOME": {
        "title": "Home Phone",
        "type": "string",
        "description": "Enter Home Phone"
      },
      "PHONE_MOBILE": {
        "title": "Mobile Phone",
        "type": "string",
        "description": "Enter Mobile Phone"
      },
      "PHONE_OTHER": {
        "title": "Other Phone",
        "type": "string",
        "description": "Enter Other Phone"
      },
      "PHONE_ASSISTANT": {
        "title": "Assistant Phone",
        "type": "string",
        "description": "Enter Assistant Phone"
      },
      "PHONE_FAX": {
        "title": "Fax",
        "type": "string",
        "description": "Enter Fax"
      },
      "EMAIL_ADDRESS": {
        "title": "Email Address",
        "type": "string",
        "description": "Enter Email Address"
      },
      "ASSISTANT_NAME": {
        "title": "Assistant Name",
        "type": "string",
        "description": "Enter Assistant Name"
      },
      "ADDRESS_MAIL_STREET": {
        "title": "Mailing Street",
        "type": "string",
        "description": "Enter Mailing Street"
      },
      "ADDRESS_MAIL_CITY": {
        "title": "Mailing City",
        "type": "string",
        "description": "Enter Mailing City"
      },
      "ADDRESS_MAIL_STATE": {
        "title": "Mailing State",
        "type": "string",
        "description": "Enter Mailing State"
      },
      "ADDRESS_MAIL_POSTCODE": {
        "title": "Mailing Postal Code",
        "type": "string",
        "description": "Enter Mailing Postal Code"
      },
      "ADDRESS_MAIL_COUNTRY": {
        "title": "Mailing Country",
        "type": "string",
        "description": "Enter Mailing Country"
      },
      "ADDRESS_OTHER_STREET": {
        "title": "Other Street",
        "type": "string",
        "description": "Enter Other Street"
      },
      "ADDRESS_OTHER_CITY": {
        "title": "Other City",
        "type": "string",
        "description": "Enter Other City"
      },
      "ADDRESS_OTHER_STATE": {
        "title": "Other State",
        "type": "string",
        "description": "Enter Other State"
      },
      "ADDRESS_OTHER_POSTCODE": {
        "title": "Other Postal Code",
        "type": "string",
        "description": "Enter Other Postal Code"
      },
      "ADDRESS_OTHER_COUNTRY": {
        "title": "Other Country",
        "type": "string",
        "description": "Enter Other Country"
      },
      "ORGANISATION_ID": {
        "title": "Organisation Id",
        "type": "integer",
        "description": "Enter Organisation Id"
      },
      "TITLE": {
        "title": "Title",
        "type": "string",
        "description": "Enter Title"
      },
      "BACKGROUND": {
        "title": "Description",
        "type": "string",
        "description": "Enter Description"
      },
      "EMAIL_OPTED_OUT": {
        "title": "Email Opted Out",
        "type": "boolean",
        "description": "Enter true for email opt out"
      },
      "TAGS": {
        "title": "Tags",
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "TAG_NAME": {
              "title": "Tag Name",
              "type": "string",
              "description": "Enter Tag name with out space" 
            }
          }
        }
      },
      "DATES": {
        "title": "Dates",
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "OCCASION_NAME": {
              "title": "Occasion Name",
              "type": "string",
              "description": "Enter Occasion name" 
            },
            "OCCASION_DATE": {
              "title": "Occasion Date",
              "type": "string",
              "description": "Enter Occasion Date" 
            },
            "REPEAT_YEARLY": {
              "title": "Repeat Yearly",
              "type": "boolean",
              "description": "Enter true for yearly repeat" 
            },
            "CREATE_TASK_YEARLY": {
              "title": "Reminder",
              "type": "boolean",
              "description": "Enter true for setting reminder" 
            }
          }
        }
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "CONTACT_ID": {
        "title": "CONTACT_ID",
        "type": "integer",
        "displayTitle": "Contact Id"
      },
      "SALUTATION": {
        "title": "SALUTATION",
        "type": "string",
        "displayTitle": "Salutation"
      },
      "FIRST_NAME": {
        "title": "FIRST_NAME",
        "type": "string",
        "displayTitle": "First Name"
      },
      "LAST_NAME": {
        "title": "LAST_NAME",
        "type": "string",
        "displayTitle": "Last Name"
      },
      "IMAGE_URL": {
        "title": "IMAGE_URL",
        "type": "string",
        "displayTitle": "Image Url"
      },
      "BACKGROUND": {
        "title": "BACKGROUND",
        "type": "string",
        "displayTitle": "Description"
      },
      "OWNER_USER_ID": {
        "title": "OWNER_USER_ID",
        "type": "integer",
        "displayTitle": "Owner User Id"
      },
      "DATE_CREATED_UTC": {
        "title": "DATE_CREATED_UTC",
        "type": "string",
        "displayTitle": "Date Created"
      },
      "DATE_UPDATED_UTC": {
        "title": "DATE_UPDATED_UTC",
        "type": "string",
        "displayTitle": "Date Updated"
      },
      "SOCIAL_LINKEDIN": {
        "title": "SOCIAL_LINKEDIN",
        "type": "string",
        "displayTitle": "Social Linkedin"
      },
      "SOCIAL_FACEBOOK": {
        "title": "SOCIAL_FACEBOOK",
        "type": "string",
        "displayTitle": "Social Facebook"
      },
      "SOCIAL_TWITTER": {
        "title": "SOCIAL_TWITTER",
        "type": "string",
        "displayTitle": "Social Twitter"
      },
      "DATE_OF_BIRTH": {
        "title": "DATE_OF_BIRTH",
        "type": "string",
        "displayTitle": "Date of Birth"
      },
      "PHONE": {
        "title": "PHONE",
        "type": "string",
        "displayTitle": "Phone"
      },
      "PHONE_HOME": {
        "title": "PHONE_HOME",
        "type": "string",
        "displayTitle": "Home Phone"
      },
      "PHONE_MOBILE": {
        "title": "PHONE_MOBILE",
        "type": "string",
        "displayTitle": "Mobile Phone"
      },
      "PHONE_OTHER": {
        "title": "PHONE_OTHER",
        "type": "string",
        "displayTitle": "Other Phone"
      },
      "PHONE_ASSISTANT": {
        "title": "PHONE_ASSISTANT",
        "type": "string",
        "displayTitle": "Assistant Phone"
      },
      "PHONE_FAX": {
        "title": "PHONE_FAX",
        "type": "string",
        "displayTitle": "Fax"
      },
      "EMAIL_ADDRESS": {
        "title": "EMAIL_ADDRESS",
        "type": "string",
        "displayTitle": "Email Address"
      },
      "ASSISTANT_NAME": {
        "title": "ASSISTANT_NAME",
        "type": "string",
        "displayTitle": "Assistant Name"
      },
      "ADDRESS_MAIL_STREET": {
        "title": "ADDRESS_MAIL_STREET",
        "type": "string",
        "displayTitle": "Mailing Street"
      },
      "ADDRESS_MAIL_CITY": {
        "title": "ADDRESS_MAIL_CITY",
        "type": "string",
        "displayTitle": "Mailing City"
      },
      "ADDRESS_MAIL_STATE": {
        "title": "ADDRESS_MAIL_STATE",
        "type": "string",
        "displayTitle": "Mailing State"
      },
      "ADDRESS_MAIL_POSTCODE": {
        "title": "ADDRESS_MAIL_POSTCODE",
        "type": "string",
        "displayTitle": "Mailing Postal Code"
      },
      "ADDRESS_MAIL_COUNTRY": {
        "title": "ADDRESS_MAIL_COUNTRY",
        "type": "string",
        "displayTitle": "Mailing Country"
      },
      "ADDRESS_OTHER_STREET": {
        "title": "ADDRESS_OTHER_STREET",
        "type": "string",
        "displayTitle": "Other Street"
      },
      "ADDRESS_OTHER_CITY": {
        "title": "ADDRESS_OTHER_CITY",
        "type": "string",
        "displayTitle": "Other City"
      },
      "ADDRESS_OTHER_STATE": {
        "title": "ADDRESS_OTHER_STATE",
        "type": "string",
        "displayTitle": "Other State"
      },
      "ADDRESS_OTHER_POSTCODE": {
        "title": "ADDRESS_MAIL_POSTCODE",
        "type": "string",
        "displayTitle": "Other Postal Code"
      },
      "ADDRESS_OTHER_COUNTRY": {
        "title": "ADDRESS_MAIL_COUNTRY",
        "type": "string",
        "displayTitle": "Other Country"
      },
      "LAST_ACTIVITY_DATE_UTC": {
        "title": "LAST_ACTIVITY_DATE_UTC",
        "type": "string",
        "displayTitle": "Last Activity Date"
      },
      "NEXT_ACTIVITY_DATE_UTC": {
        "title": "NEXT_ACTIVITY_DATE_UTC",
        "type": "string",
        "displayTitle": "Next Activity Date"
      },
      "CREATED_USER_ID": {
        "title": "CREATED_USER_ID",
        "type": "integer",
        "displayTitle": "Created User Id"
      },
      "ORGANISATION_ID": {
        "title": "ORGANISATION_ID",
        "type": "integer",
        "displayTitle": "Organisation Id"
      },
      "TITLE": {
        "title": "TITLE",
        "type": "string",
        "displayTitle": "Title"
      },
      "EMAIL_OPTED_OUT": {
        "title": "EMAIL_OPTED_OUT",
        "type": "boolean",
        "displayTitle": "Email Opted Out"
      },
      "TAGS": {
        "title": "Tags",
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "TAG_NAME": {
              "title": "Tag Name",
              "type": "string",
              "displayTitle": "Tag Name" 
            }
          }
        }
        
      },
      "DATES": {
        "title": "Dates",
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "OCCASION_NAME": {
              "title": "Occasion Name",
              "type": "string",
              "displayTitle": "Occasion name" 
            },
            "OCCASION_DATE": {
              "title": "Occasion Date",
              "type": "string",
              "displayTitle": "Occasion Date" 
            },
            "REPEAT_YEARLY": {
              "title": "Repeat Yearly",
              "type": "boolean",
              "displayTitle": "Repeat Yearly" 
            },
            "CREATE_TASK_YEARLY": {
              "title": "Reminder",
              "type": "boolean",
              "displayTitle": "Reminder" 
            }
          }
        }
      }
      
    }
  },

  mock_input:{
    "FIRST_NAME": "Name 2"
  },

  execute: function(input, output){
    let request = require('request');
    //Create the buffer object by specifying utf8 as encoding type
    let bufferObj = Buffer.from(input.auth.username, "utf8");
    //Encode as base64 string
    let base64String = bufferObj.toString("base64");

    var data = {
      "SALUTATION": input.SALUTATION,
      "CONTACT_ID": input.CONTACT_ID,
      "FIRST_NAME": input.FIRST_NAME,
      "LAST_NAME": input.LAST_NAME,
      "BACKGROUND": input.BACKGROUND,
      "ORGANISATION_ID": input.ORGANISATION_ID,
      "SOCIAL_FACEBOOK": input.SOCIAL_FACEBOOK,
      "SOCIAL_TWITTER": input.SOCIAL_TWITTER,
      "SOCIAL_LINKEDIN": input.SOCIAL_LINKEDIN,
      "DATE_OF_BIRTH": input.DATE_OF_BIRTH,
      "PHONE": input.PHONE,
      "PHONE_HOME": input.PHONE_HOME,
      "PHONE_MOBILE": input.PHONE_MOBILE,
      "PHONE_ASSISTANT": input.PHONE_ASSISTANT,
      "PHONE_OTHER": input.PHONE_OTHER,
      "PHONE_ASSISTANT": input.PHONE_ASSISTANT,
      "PHONE_FAX": input.PHONE_FAX,
      "EMAIL_ADDRESS": input.EMAIL_ADDRESS,
      "ASSISTANT_NAME": input.ASSISTANT_NAME,
      "ADDRESS_MAIL_STREET": input.ADDRESS_MAIL_STREET,
      "ADDRESS_MAIL_CITY": input.ADDRESS_MAIL_CITY,
      "ADDRESS_MAIL_STATE": input.ADDRESS_MAIL_STATE,
      "ADDRESS_MAIL_POSTCODE": input.ADDRESS_MAIL_POSTCODE,
      "ADDRESS_MAIL_COUNTRY": input.ADDRESS_MAIL_COUNTRY,
      "ADDRESS_OTHER_STREET": input.ADDRESS_OTHER_STREET,
      "ADDRESS_OTHER_CITY": input.ADDRESS_OTHER_CITY,
      "ADDRESS_OTHER_STATE": input.ADDRESS_OTHER_STATE,
      "ADDRESS_OTHER_POSTCODE": input.ADDRESS_OTHER_POSTCODE,
      "ADDRESS_OTHER_COUNTRY": input.ADDRESS_OTHER_COUNTRY,
      "TITLE": input.TITLE,
      "EMAIL_OPTED_OUT": input.EMAIL_OPTED_OUT,
      "TAGS": input.TAGS,
      "DATES": input.DATES

    }
    request({
      url: "https://api.na1.insightly.com/v3.1/Contacts",
      headers: {
        Authorization: "Basic " + base64String
      },
      method: "PUT",
      json: data
    },
      function(err, res, body) {
        if (err) {
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string') {
              body = JSON.parse(body);
            }
            return output(null, body);
          } else {
            if (body && body.errors) {
              return output(JSON.stringify(body.errors));
            }
            return output(JSON.stringify(body));
          }
        }
      }
    )
  }

}
