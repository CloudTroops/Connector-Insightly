module.exports = {

  name: "add_a_product",

  title: "Add A Product",

  description: "",
  version: "v1",

  input:{
    title: "Add A Product",
    type: "object",
    properties: {
      "PRODUCT_NAME": {
        "title": "Product Name",
        "type": "string",
        "description": "Enter Product Name",
        "minLength": "1"
      },
      "PRODUCT_CODE": {
        "title": "Product Code",
        "type": "string",
        "description": "Enter Product Code"
      },
      "PRODUCT_SKU": {
        "title": "Product SKU",
        "type": "string",
        "description": "Enter Product SKU"
      },
      "DESCRIPTION": {
        "title": "Description",
        "type": "string",
        "description": "Enter Description"
      },
      "PRODUCT_FAMILY": {
        "title": "Product Family",
        "type": "string",
        "description": "Enter Product Family"
      },
      "PRODUCT_IMAGE_URL": {
        "title": "Product Image Url",
        "type": "string",
        "description": "Enter Product Image Url"
      },
      "DEFAULT_PRICE": {
        "title": "Default Price",
        "type": "number",
        "description": "Enter Default Price"
      },
      "ACTIVE": {
        "title": "Active",
        "type": "boolean",
        "description": "Active"
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "PRODUCT_ID": {
        "title": "PRODUCT_ID",
        "type": "integer",
        "displayTitle": "Product Id"
      },
      "PRODUCT_NAME": {
        "title": "PRODUCT_NAME",
        "type": "string",
        "displayTitle": "Product Name"
      },
      "PRODUCT_CODE": {
        "title": "PRODUCT_CODE",
        "type": "string",
        "displayTitle": "Product Code"
      },
      "PRODUCT_SKU": {
        "title": "PRODUCT_SKU",
        "type": "string",
        "displayTitle": "Product SKU"
      },
      "PRODUCT_FAMILY": {
        "title": "PRODUCT_FAMILY",
        "type": "string",
        "displayTitle": "Product Family"
      },
      "DESCRIPTION": {
        "title": "DESCRIPTION",
        "type": "string",
        "displayTitle": "Description"
      },
      "PRODUCT_IMAGE_URL": {
        "title": "PRODUCT_IMAGE_URL",
        "type": "string",
        "displayTitle": "Product Image Url"
      },
      "DEFAULT_PRICE": {
        "title": "DEFAULT_PRICE",
        "type": "number",
        "displayTitle": "Default Price"
      },
      "ACTIVE": {
        "title": "ACTIVE",
        "type": "boolean",
        "displayTitle": "Active"
      },
      "CURRENCY_CODE": {
        "title": "CURRENCY_CODE",
        "type": "string",
        "displayTitle": "Currency Code"
      },
      "OWNER_USER_ID": {
        "title": "OWNER_USER_ID",
        "type": "integer",
        "displayTitle": "Owner User Id"
      },
      "DATE_CREATED_UTC": {
        "title": "DATE_CREATED_UTC",
        "type": "string",
        "displayTitle": "Date Created"
      },
      "DATE_UPDATED_UTC": {
        "title": "DATE_UPDATED_UTC",
        "type": "string",
        "displayTitle": "Date Updated"
      },
      "CREATED_USER_ID": {
        "title": "CREATED_USER_ID",
        "type": "integer",
        "displayTitle": "Created User Id"
      },
      
    }
  },

  mock_input:{
    "PRODUCT_NAME": "Dummy Product"
  },

  execute: function(input, output){
    let request = require('request');
    //Create the buffer object by specifying utf8 as encoding type
    let bufferObj = Buffer.from(input.auth.username, "utf8");
    //Encode as base64 string
    let base64String = bufferObj.toString("base64");

    var data = {
      "PRODUCT_NAME": input.PRODUCT_NAME,
      "PRODUCT_CODE": input.PRODUCT_CODE,
      "PRODUCT_SKU": input.PRODUCT_SKU,
      "DESCRIPTION": input.DESCRIPTION,
      "PRODUCT_FAMILY": input.PRODUCT_FAMILY,
      "PRODUCT_IMAGE_URL": input.PRODUCT_IMAGE_URL,
      "DEFAULT_PRICE": input.DEFAULT_PRICE,
      "ACTIVE": input.ACTIVE
    }
    request({
      url: "https://api.na1.insightly.com/v3.1/Product",
      headers: {
        Authorization: "Basic " + base64String
      },
      method: "POST",
      json: data
    },
      function(err, res, body) {
        if (err) {
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string') {
              body = JSON.parse(body);
            }
            return output(null, body);
          } else {
            if (body && body.errors) {
              return output(JSON.stringify(body.errors));
            }
            return output(JSON.stringify(body));
          }
        }
      }
    )
  }

}