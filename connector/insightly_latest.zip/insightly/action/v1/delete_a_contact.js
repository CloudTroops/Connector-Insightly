module.exports = {

  name: "delete_a_contact",

  title: "Delete A Contact",

  description: "",
  version: "v1",

  input:{
    title: "Delete A Contact",
    type: "object",
    properties: {
      "id": {
        "title": "Id",
        "type": "integer",
        "displayTitle": "Enter record's id"
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {

    }
  },

  mock_input:{
    "id": 335779648
  },

  execute: function(input, output){
    let request = require('request');
    //Create the buffer object by specifying utf8 as encoding type
    let bufferObj = Buffer.from(input.auth.username, "utf8");
    //Encode as base64 string
    let base64String = bufferObj.toString("base64");
    request({
      url: "https://api.na1.insightly.com/v3.1/Contacts/" + input.id,
      headers: {
        Authorization: "Basic " + base64String
      },
      method: "DELETE"
    },
      function(err, res, body) {
        if (err) {
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode == 202) {
            output(null, { data : "Delete Successful"});
          } else {
            if (body && body.errors) {
              return output(JSON.stringify(body.errors));
            }
            return output(body);
          }
        }
      }
    )
  }
}
