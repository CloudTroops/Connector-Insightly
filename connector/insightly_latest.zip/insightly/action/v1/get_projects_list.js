module.exports = {

  name: "get_projects_list",

  title: "Get Projects List",

  description: "",
  version: "v1",

  input:{
    title: "Get Projects List",
    type: "object",
    properties: {
      "skip": {
        "title": "Skip",
        "type": "integer",
        "description": "Enter the number of users to skip",
      },
      "top": {
        "title": "Top",
        "type": "integer",
        "description": "Enter the maximum number of users to return in the response",
      },
      "count_total": {
        "title": "Total Count",
        "type": "boolean",
        "description": "Default value is false, Set it to true if total no of records should be returned"
      },
      "brief": {
        "title": "Brief",
        "type": "boolean",
        "description": "Default value is false, Set it to true if response should contain top level properties only"
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "PROJECT_ID": {
        "title": "PROJECT_ID",
        "type": "integer",
        "displayTitle": "Project Id"
      },
      "PROJECT_NAME": {
        "title": "PROJECT_NAME",
        "type": "string",
        "displayTitle": "Project Name"
      },
      "STATUS": {
        "title": "STATUS",
        "type": "string",
        "displayTitle": "Status"
      },
      "PROJECT_DETAILS": {
        "title": "PROJECT_DETAILS",
        "type": "string",
        "displayTitle": "Project Details"
      },
      "STARTED_DATE": {
        "title": "STARTED_DATE",
        "type": "string",
        "displayTitle": "Started Date"
      },
      "COMPLETED_DATE": {
        "title": "COMPLETED_DATE",
        "type": "string",
        "displayTitle": "Completed Date"
      },
      "OPPORTUNITY_ID": {
        "title": "OPPORTUNITY_ID",
        "type": "integer",
        "displayTitle": "Opportunity Id"
      },
      "CATEGORY_ID": {
        "title": "CATEGORY_ID",
        "type": "integer",
        "displayTitle": "Category Id"
      },
      "PIPELINE_ID": {
        "title": "PIPELINE_ID",
        "type": "integer",
        "displayTitle": "Pipeline Id"
      },
      "STAGE_ID": {
        "title": "STAGE_ID",
        "type": "integer",
        "displayTitle": "Stage Id"
      },
      "IMAGE_URL": {
        "title": "IMAGE_URL",
        "type": "string",
        "displayTitle": "Image Url"
      },
      "OWNER_USER_ID": {
        "title": "OWNER_USER_ID",
        "type": "integer",
        "displayTitle": "Owner User Id"
      },
      "DATE_CREATED_UTC": {
        "title": "DATE_CREATED_UTC",
        "type": "string",
        "displayTitle": "Date Created"
      },
      "DATE_UPDATED_UTC": {
        "title": "DATE_UPDATED_UTC",
        "type": "string",
        "displayTitle": "Date Updated"
      },
      "LAST_ACTIVITY_DATE_UTC": {
        "title": "LAST_ACTIVITY_DATE_UTC",
        "type": "string",
        "displayTitle": "Last Activtiy Date"
      },
      "NEXT_ACTIVITY_DATE_UTC": {
        "title": "NEXT_ACTIVITY_DATE_UTC",
        "type": "string",
        "displayTitle": "Next Activtiy Date"
      },
      "CREATED_USER_ID": {
        "title": "CREATED_USER_ID",
        "type": "integer",
        "displayTitle": "Created User Id"
      },
      "RESPONSIBLE_USER_ID": {
        "title": "RESPONSIBLE_USER_ID",
        "type": "integer",
        "displayTitle": "Responsible User Id"
      },
      "TAGS": {
        "title": "Tags",
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "TAG_NAME": {
              "title": "Tag Name",
              "type": "string",
              "displayTitle": "Tag Name" 
            }
          }
        }
        
      },
      "LINKS": {
        "title": "Links",
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "OBJECT_NAME": {
              "title": "OBJECT_NAME",
              "type": "string",
              "displayTitle": "Object Name" 
            },
            "LINK_ID": {
              "title": "LINK_ID",
              "type": "integer",
              "displayTitle": "Link Id" 
            },
            "OBJECT_ID": {
              "title": "OBJECT_ID",
              "type": "integer",
              "displayTitle": "Object Id" 
            },
            "LINK_OBJECT_ID": {
              "title": "LINK_OBJECT_ID",
              "type": "integer",
              "displayTitle": "Link Object Id" 
            },
            "ROLE": {
              "title": "ROLE",
              "type": "string",
              "displayTitle": "Role" 
            },
            "DETAILS": {
              "title": "DETAILS",
              "type": "string",
              "displayTitle": "Details" 
            },
            "RELATIONSHIP_ID": {
              "title": "RELATIONSHIP_ID",
              "type": "integer",
              "displayTitle": "Relationship Id" 
            },
            "IS_FORWARD": {
              "title": "IS_FORWARD",
              "type": "boolean",
              "displayTitle": "Is Forward" 
            }
          }
        }
        
      }
    }
  },

  mock_input:{
  },

  execute: function(input, output){
    let request = require('request');
    //Create the buffer object by specifying utf8 as encoding type
    let bufferObj = Buffer.from(input.auth.username, "utf8");
    //Encode as base64 string
    let base64String = bufferObj.toString("base64");

    request({
      url: "https://api.na1.insightly.com/v3.1/Projects?top=" + input.top+"&skip=" + input.skip+"&brief="+input.brief+"&count_total="+input.count_total,
      headers: {
        Authorization: "Basic " + base64String
      },
      method: "GET"
    },
      function(err, res, body) {
        if (err) {
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string') {
              body = JSON.parse(body);
            }
            return output(null, body);
          } else {
            if (body && body.errors) {
              return output(JSON.stringify(body.errors));
            }
            return output(JSON.stringify(body));
          }
        }
      }
    )
  }

}