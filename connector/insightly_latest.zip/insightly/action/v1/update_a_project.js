module.exports = {

  name: "update_a_project",

  title: "Update A Project",

  description: "",
  version: "v1",

  input:{
    title: "Update A Project",
    type: "object",
    properties: {
      "PROJECT_ID": {
        "title": "Project Id",
        "type": "integer",
        "description": "Enter Project Id",
        "minLength": "1"
      },
      "PROJECT_NAME": {
        "title": "Project Name",
        "type": "string",
        "description": "Enter Project Name",
        "minLength": "1"
      },
      "STATUS": {
        "title": "STATUS",
        "type": "string",
        "description": "Enter Status",
        "minLength": "1"
      },
      "PROJECT_DETAILS": {
        "title": "Project Details",
        "type": "string",
        "description": "Enter Project Details"
      },
      "STARTED_DATE": {
        "title": "Started Date",
        "type": "string",
        "description": "Enter Started Date"
      },
      "COMPLETED_DATE": {
        "title": "Completed Date",
        "type": "string",
        "description": "Enter Completed Date"
      },
      "CATEGORY_ID": {
        "title": "Category Id",
        "type": "integer",
        "description": "Enter Category Id"
      },
      "IMAGE_URL": {
        "title": "Image Url",
        "type": "string",
        "description": "Enter Image Url"
      },
      "RESPONSIBLE_USER_ID": {
        "title": "Responsible User Id",
        "type": "integer",
        "description": "Enter Responsible User Id"
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "PROJECT_ID": {
        "title": "PROJECT_ID",
        "type": "integer",
        "displayTitle": "Project Id"
      },
      "PROJECT_NAME": {
        "title": "PROJECT_NAME",
        "type": "string",
        "displayTitle": "Project Name"
      },
      "STATUS": {
        "title": "STATUS",
        "type": "string",
        "displayTitle": "Status"
      },
      "PROJECT_DETAILS": {
        "title": "PROJECT_DETAILS",
        "type": "string",
        "displayTitle": "Project Details"
      },
      "STARTED_DATE": {
        "title": "STARTED_DATE",
        "type": "string",
        "displayTitle": "Started Date"
      },
      "COMPLETED_DATE": {
        "title": "COMPLETED_DATE",
        "type": "string",
        "displayTitle": "Completed Date"
      },
      "OPPORTUNITY_ID": {
        "title": "OPPORTUNITY_ID",
        "type": "integer",
        "displayTitle": "Opportunity Id"
      },
      "CATEGORY_ID": {
        "title": "CATEGORY_ID",
        "type": "integer",
        "displayTitle": "Category Id"
      },
      "PIPELINE_ID": {
        "title": "PIPELINE_ID",
        "type": "integer",
        "displayTitle": "Pipeline Id"
      },
      "STAGE_ID": {
        "title": "STAGE_ID",
        "type": "integer",
        "displayTitle": "Stage Id"
      },
      "IMAGE_URL": {
        "title": "IMAGE_URL",
        "type": "string",
        "displayTitle": "Image Url"
      },
      "OWNER_USER_ID": {
        "title": "OWNER_USER_ID",
        "type": "integer",
        "displayTitle": "Owner User Id"
      },
      "DATE_CREATED_UTC": {
        "title": "DATE_CREATED_UTC",
        "type": "string",
        "displayTitle": "Date Created"
      },
      "DATE_UPDATED_UTC": {
        "title": "DATE_UPDATED_UTC",
        "type": "string",
        "displayTitle": "Date Updated"
      },
      "LAST_ACTIVITY_DATE_UTC": {
        "title": "LAST_ACTIVITY_DATE_UTC",
        "type": "string",
        "displayTitle": "Last Activtiy Date"
      },
      "NEXT_ACTIVITY_DATE_UTC": {
        "title": "NEXT_ACTIVITY_DATE_UTC",
        "type": "string",
        "displayTitle": "Next Activtiy Date"
      },
      "CREATED_USER_ID": {
        "title": "CREATED_USER_ID",
        "type": "integer",
        "displayTitle": "Created User Id"
      },
      "RESPONSIBLE_USER_ID": {
        "title": "RESPONSIBLE_USER_ID",
        "type": "integer",
        "displayTitle": "Responsible User Id"
      },
      "TAGS": {
        "title": "Tags",
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "TAG_NAME": {
              "title": "Tag Name",
              "type": "string",
              "displayTitle": "Tag Name" 
            }
          }
        }
        
      },
      "LINKS": {
        "title": "Links",
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "OBJECT_NAME": {
              "title": "OBJECT_NAME",
              "type": "string",
              "displayTitle": "Object Name" 
            },
            "LINK_ID": {
              "title": "LINK_ID",
              "type": "integer",
              "displayTitle": "Link Id" 
            },
            "OBJECT_ID": {
              "title": "OBJECT_ID",
              "type": "integer",
              "displayTitle": "Object Id" 
            },
            "LINK_OBJECT_ID": {
              "title": "LINK_OBJECT_ID",
              "type": "integer",
              "displayTitle": "Link Object Id" 
            },
            "ROLE": {
              "title": "ROLE",
              "type": "string",
              "displayTitle": "Role" 
            },
            "DETAILS": {
              "title": "DETAILS",
              "type": "string",
              "displayTitle": "Details" 
            },
            "RELATIONSHIP_ID": {
              "title": "RELATIONSHIP_ID",
              "type": "integer",
              "displayTitle": "Relationship Id" 
            },
            "IS_FORWARD": {
              "title": "IS_FORWARD",
              "type": "boolean",
              "displayTitle": "Is Forward" 
            }
          }
        }
        
      }
    }
  },

  mock_input:{
     "PROJECT_NAME": "Test Project",
     "PROJECT_ID": 322,
     "STATUS": "Not Started"
  },

  execute: function(input, output){
    let request = require('request');
    //Create the buffer object by specifying utf8 as encoding type
    let bufferObj = Buffer.from(input.auth.username, "utf8");
    //Encode as base64 string
    let base64String = bufferObj.toString("base64");

    var data = {
      "PROJECT_ID": input.PROJECT_ID,
      "PROJECT_NAME": input.PROJECT_NAME,
      "STATUS": input.STATUS,
      "PROJECT_DETAILS": input.PROJECT_DETAILS,
      "STARTED_DATE": input.STARTED_DATE,
      "COMPLETED_DATE": input.COMPLETED_DATE,
      "CATEGORY_ID": input.CATEGORY_ID,
      "IMAGE_URL": input.IMAGE_URL,
      "RESPONSIBLE_USER_ID": input.RESPONSIBLE_USER_ID
    }
    request({
      url: "https://api.na1.insightly.com/v3.1/Projects",
      headers: {
        Authorization: "Basic " + base64String
      },
      method: "PUT",
      json: data
    },
      function(err, res, body) {
        if (err) {
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string') {
              body = JSON.parse(body);
            }
            return output(null, body);
          } else {
            if (body && body.errors) {
              return output(JSON.stringify(body.errors));
            }
            return output(JSON.stringify(body));
          }
        }
      }
    )
  }

}
