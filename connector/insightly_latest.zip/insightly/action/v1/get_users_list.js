module.exports = {

  name: "get_users_list",

  title: "Get Users List",

  description: "",
  version: "v1",

  input:{
    title: "Get Users List",
    type: "object",
    properties: {
      "skip": {
        "title": "Skip",
        "type": "integer",
        "description": "Enter the number of users to skip",
      },
      "top": {
        "title": "Top",
        "type": "integer",
        "description": "Enter the maximum number of users to return in the response",
      },
      "count_total": {
        "title": "Total Count",
        "type": "boolean",
        "description": "Default value is false, Set it to true if total no of records should be returned"
      }
    }
  },

  output: {
    title: "output",
  	type: "object",
  	properties: {
      "USER_ID": {
        "title": "USER_ID",
        "type": "integer",
        "displayTitle": "User Id"
      },
      "CONTACT_ID": {
        "title": "CONTACT_ID",
        "type": "integer",
        "displayTitle": "Contact Id"
      },
      "FIRST_NAME": {
        "title": "FIRST_NAME",
        "type": "string",
        "displayTitle": "First Name"
      },
      "LAST_NAME": {
        "title": "LAST_NAME",
        "type": "string",
        "displayTitle": "Last Name"
      },
      "TIMEZONE_ID": {
        "title": "TIMEZONE_ID",
        "type": "string",
        "displayTitle": "Time Zone Id"
      },
      "EMAIL_ADDRESS": {
        "title": "EMAIL_ADDRESS",
        "type": "string",
        "displayTitle": "Email Address"
      },
      "EMAIL_DROPBOX_IDENTIFIER": {
        "title": "EMAIL_DROPBOX_IDENTIFIER",
        "type": "string",
        "displayTitle": "Email Dropbox Identifier"
      },
      "EMAIL_DROPBOX_ADDRESS": {
        "title": "EMAIL_DROPBOX_ADDRESS",
        "type": "string",
        "displayTitle": "Email Dropbox Address"
      },
      "ADMINISTRATOR": {
        "title": "ADMINISTRATOR",
        "type": "boolean",
        "displayTitle": "Administrator"
      },
      "ACCOUNT_OWNER": {
        "title": "ACCOUNT_OWNER",
        "type": "string",
        "displayTitle": "Account Owner"
      },
      "ACTIVE": {
        "title": "ACTIVE",
        "type": "boolean",
        "displayTitle": "Active"
      },
      "DATE_CREATED_UTC": {
        "title": "DATE_CREATED_UTC",
        "type": "string",
        "displayTitle": "Date Created UTC"
      },
      "DATE_UPDATED_UTC": {
        "title": "DATE_UPDATED_UTC",
        "type": "string",
        "displayTitle": "Date Updated UTC"
      },
      "USER_CURRENCY": {
        "title": "USER_CURRENCY",
        "type": "string",
        "displayTitle": "User Currency"
      },
      "CONTACT_DISPLAY": {
        "title": "CONTACT_DISPLAY",
        "type": "string",
        "displayTitle": "Contact Display"
      },
      "CONTACT_ORDER": {
        "title": "CONTACT_ORDER",
        "type": "string",
        "displayTitle": "Contact Order"
      },
      "TASK_WEEK_START": {
        "title": "TASK_WEEK_START",
        "type": "integer",
        "displayTitle": "Task Week Start"
      },
      "INSTANCE_ID": {
        "title": "INSTANCE_ID",
        "type": "integer",
        "displayTitle": "Instance Id"
      },
      "PROFILE_ID": {
        "title": "PROFILE_ID",
        "type": "integer",
        "displayTitle": "Profile Id"
      },
      "ROLE_ID": {
        "title": "ROLE_ID",
        "type": "integer",
        "displayTitle": "Role Id"
      }

    }
  },

  mock_input:{},

  execute: function(input, output){
    let request = require('request');
    //Create the buffer object by specifying utf8 as encoding type
    let bufferObj = Buffer.from(input.auth.username, "utf8");
    //Encode as base64 string
    let base64String = bufferObj.toString("base64");
    request({
      url: "https://api.na1.insightly.com/v3.1/Users?top=" + input.top+"&skip=" + input.skip+"&count_total="+input.count_total,
      headers: {
        Authorization: "Basic " + base64String
      },
      method: "GET"
    },
      function(err, res, body) {
        if (err) {
          return output(JSON.stringify(err));
        } else {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            if (typeof (body) == 'string') {
              body = JSON.parse(body);
            }
            return output(null, body);
          } else {
            if (body && body.errors) {
              return output(JSON.stringify(body.errors));
            }
            return output(JSON.stringify(body));
          }
        }
      }
    )
  }

}
