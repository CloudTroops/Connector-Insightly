
module.exports = {
 label : 'Connect to Insightly',		
 mock_input: { 
  username: "686cf62c-2c64-478b-8076-4cc5a517ec9a", 
  password: "" 
 },
 validate : function (input, output){
  var request = require('request');
  //Create the buffer object by specifying utf8 as encoding type
  let bufferObj = Buffer.from(input.auth.username, "utf8");
  //Encode as base64 string
  let base64String = bufferObj.toString("base64");
  
  request({
   url: 'https://api.na1.insightly.com/v3.1/Users',
   headers: {
	Authorization: "Basic " + base64String,
	accept: "application/json"
  }
 }, 
 function(err, res, body){
  if(err){
   output(err, null)
  }
  if(res.statusCode == 401){
   output('Unauthorized')
  } else {
   output(null, 'Logged in successfull');        
  }
 })
 }
}